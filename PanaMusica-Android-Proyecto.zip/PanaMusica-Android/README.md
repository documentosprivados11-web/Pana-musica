# Pana Música — Android

Proyecto base de la app Android **Pana Música**.

**Creador:** Antonio José Barazarte

Incluye una primera implementación funcional de la interfaz: Inicio, Buscar, Biblioteca, Favoritos y Efectos/Equalizador, con identidad visual inspirada en Venezuela y siete estrellas.

## Generar APK
1. Abrir la carpeta en Android Studio.
2. Dejar que Android Studio instale/sincronice Gradle y el Android SDK solicitado.
3. Ejecutar `Build > Build APK(s)`.
4. El APK de depuración quedará en `app/build/outputs/apk/debug/app-debug.apk`.

Nota: este entorno de ChatGPT no tiene Android SDK/Gradle instalado y no puede descargar esos componentes, por lo que no puedo afirmar que el APK binario haya sido compilado aquí.
