package com.panamusica.app;

import android.app.*;import android.os.*;import android.graphics.Color;import android.content.*;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
  int navy=Color.rgb(6,19,41), yellow=Color.rgb(255,210,31), red=Color.rgb(220,35,55), blue=Color.rgb(20,80,180); LinearLayout root, content; TextView title;
  TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(18,14,18,14); return t; }
  Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundColor(Color.TRANSPARENT); return b; }
  @Override public void onCreate(Bundle b){super.onCreate(b); build();}
  void build(){
    root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(navy); setContentView(root);
    TextView creator=tv("Creador: Antonio José Barazarte",13); creator.setGravity(Gravity.CENTER); creator.setTextColor(yellow); root.addView(creator,new LinearLayout.LayoutParams(-1,50));
    title=tv("★ ★ ★ ★ ★ ★ ★\nPana Música ♪",28); title.setGravity(Gravity.CENTER); title.setTextColor(Color.WHITE); root.addView(title,new LinearLayout.LayoutParams(-1,115));
    content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); ScrollView sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    nav(); home();
  }
  void nav(){ LinearLayout n=new LinearLayout(this); n.setGravity(Gravity.CENTER); String[] a={"Inicio","Buscar","Biblioteca","Favoritos","Efectos"}; for(String s:a){Button x=btn(s); n.addView(x,new LinearLayout.LayoutParams(0,58,1)); x.setOnClickListener(v->{ if(s.equals("Buscar")) search(); else if(s.equals("Biblioteca")) library(); else if(s.equals("Favoritos")) favorites(); else if(s.equals("Efectos")) effects(); else home();}); } root.addView(n); }
  void clear(){content.removeAllViews();}
  void home(){clear(); TextView h=tv("Buscar música, artista o álbum...",16); h.setBackgroundColor(Color.rgb(20,38,65)); content.addView(h,new LinearLayout.LayoutParams(-1,60)); TextView r=tv("\n🎵  Mi Música        ❤️  Favoritos        🔎  Buscar Música\n\nRECOMENDADOS PARA TI\n\n🎶  Música Llanera     🎧  Reggaetón     🇻🇪  Artistas Venezolanos\n\n▶  Reproducir música local\n",18); content.addView(r); }
  void search(){clear(); content.addView(tv("‹  Buscar Música",24)); content.addView(tv("🔎  Escribe una canción o artista",16)); content.addView(tv("Resultados\n\nCamilo — Vida de Rico\nCamilo — Tutu\nCamilo — Favorito\n\n[ Abrir en servicio autorizado ]",17));}
  void library(){clear(); content.addView(tv("Mi Biblioteca",24)); content.addView(tv("♫ Canciones    ▣ Álbumes    ♫ Artistas\n\n▶ Venezuela Mi Tierra     3:56\n▶ Despacito                  3:48\n▶ Tutu                         3:49\n▶ Ojitos Lindos            4:17",17));}
  void favorites(){clear(); content.addView(tv("❤️ Favoritos",24)); content.addView(tv("Venezuela Mi Tierra     ♥\nDímelo                         ♥\nTú Foto                         ♥\nLa Canción                    ♥",17));}
  void effects(){clear(); content.addView(tv("Ecualizador y Efectos",24)); content.addView(tv("ECUALIZADOR\n\nBajos      ┃━━━━━━●━━┃\nMedios    ┃━━━━●━━━━┃\nAgudos    ┃━━━━━━●━━┃\n\nEFECTOS DE AUDIO\n\nEco / Reverberación   ●\n\nVolumen      ┃━━━━━━●━━┃",17));}
}
